# Dispatch Core qualification Smoke  - Run: `dispatch-core-smoke-20261109T120309-b59d3e12` - Source: `b52106b47e4163d0906abbaa59d343935f4fba42` tree `0e1933cc565ad8f9b42239312c996facf2a5126a` (clean) - Candidate: `b52106b47e4163d0906abbaa59d343935f4fba42` / `dist` / SHA-256 `98017d8e20d938681ba43cc57f62cdb561248583fc52880628e3d36c12d6b569` - Control: not applicable - Sessions: 22; PASS: 18; failed/inconclusive: 4 - Paired order: AB/BA alternating; six pairs per workload/load cell; 15 seconds per timed session. - Contention: two hidden PowerShell CPU workers at BelowNormal priority. Sink: identity-verified ReceiveOnly. - Percentiles use nearest-rank ceiling; p99 is shown with sample count. No p99.9 is inferred. - Native RT allocation is not instrumented in the sink runner; see focused no-allocation test result in the accompanying command record.  ## Safety cases  | Scenario | Verdict | Exit | Reason | |---|---:|---:|---|
| canonical-single | PASS | 0 | controlled production-path evidence is clean |
| canonical-max-chord | PASS | 0 | controlled production-path evidence is clean |
| near-minimum-retrigger | PASS | 0 | controlled production-path evidence is clean |
| release-gap-stress | PASS | 0 | controlled production-path evidence is clean |
| mixed-up-down | PASS | 0 | controlled production-path evidence is clean |
| ambiguous-packet | PASS | 0 | controlled production-path evidence is clean |
| preflight-user-held | INCONCLUSIVE | 1 | native timing telemetry unavailable: telemetry has already been taken |
| modifier-held-final-boundary | PASS | 0 | modifier guard final-boundary evidence passed |
| modifier-held-after-owned | PASS | 0 | modifier guard final-boundary evidence passed |
| focus-loss | PASS | 0 | controlled production-path evidence is clean |
| target-hwnd-change | PASS | 0 | controlled production-path evidence is clean |
| owner-mismatch | PASS | 0 | window-owner authority failure stopped before the prepared sender |
| owner-query-failure | PASS | 0 | window-owner authority failure stopped before the prepared sender |
| owner-process-termination | INCONCLUSIVE | 1 | native timing telemetry unavailable: telemetry has already been taken |
| pause-resume | PASS | 0 | controlled production-path evidence is clean |
| pause-resume-release-floor | PASS | 0 | controlled production-path evidence is clean |
| suspend-resume | INCONCLUSIVE | 1 | system suspend did not commit before the bounded proof deadline |
| stop-cleanup | PASS | 0 | controlled production-path evidence is clean |
| skip-cleanup | PASS | 0 | controlled production-path evidence is clean |
| supervisor-lease-expiry | PASS | 0 | session watchdog expired after session progress stopped while the unrelated helper remained alive |
| lease-age-watchdog-delayed | FAIL | 1 | native session evidence contains a transport or residue anomaly |
| noncanonical-profile | PASS | 0 | controlled production-path evidence is clean |

## Paired performance observations

| Cell | Pair | Control p99 authored lateness (us) | Candidate p99 (us) | Delta (us) | Samples C0/final |
|---|---:|---:|---:|---:|---:|

These are evidence summaries, not an automatic performance-gate verdict. No design, gate, or rollout selection is made by this runner.

