# R3 P4 diagnostics

Run: r3-p4-20261016T145957238Z-be3ec0ab
Source revision: 3a96be29eb2e9ceff03db9ab659b073cd7547c17
Runtime/base revision: b012b0a1c135a9176cfc7c6aa8696fa0be29a481
Toolchain: rustc 1.99.1 (58cf8f9c3 2026-10-13); cargo 1.99.1 (5f94df478 2026-08-27); Bun 1.4.3
Transport: deterministic test-support mock for HOL; no SendInput or game process.

## Head-of-line and prepared packet scenarios

| Scenario | Packet | Authored target (us) | Ready floor (us) | Actual pre-call (us) | Completion (us) | Sender duration (us) | Blocking packet/keymask | Delay due to earlier packet (us) | Floor violation | Attempts |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- | ---: |
| hol-a-up-floor-delays-b | 0 | 100000 | 100000 | 100000 | 110000 | 10000 | none | 0 | False | 1 |
| hol-a-up-floor-delays-b | 1 | 117167 | 127167 | 127167 | 127567 | 400 | 0/0x0001 | 10000 | False | 1 |
| hol-a-up-floor-delays-b | 2 | 118000 | 118000 | 127567 | 127767 | 200 | 1/0x0001 | 9567 | False | 1 |
| hol-a-up-floor-delays-b | 3 | 135167 | 144934 | 144934 | 145034 | 100 | 2/0x0002 | 9767 | False | 1 |
| hol-mixed-up-a-down-b-one-syscall | 0 | 100000 | 100000 | 100000 | 110000 | 10000 | none | 0 | False | 1 |
| hol-mixed-up-a-down-b-one-syscall | 1 | 118000 | 127167 | 127167 | 127767 | 600 | 0/0x0001 | 9167 | False | 1 |
| hol-mixed-up-a-down-b-one-syscall | 2 | 135167 | 144934 | 144934 | 145034 | 100 | 1/0x0002 | 9767 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 0 | 100000 | 100000 | 100000 | 110000 | 10000 | none | 0 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 1 | 117167 | 127167 | 127167 | 130167 | 3000 | 0/0x0001 | 10000 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 2 | 118000 | 118000 | 130167 | 130247 | 80 | 1/0x0001 | 12167 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 3 | 119000 | 119000 | 130247 | 130337 | 90 | 2/0x0002 | 11247 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 4 | 120000 | 120000 | 130337 | 130437 | 100 | 3/0x0004 | 10337 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 5 | 135167 | 147414 | 147414 | 147514 | 100 | 2/0x0002 | 12247 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 6 | 136167 | 147504 | 147514 | 147614 | 100 | 5/0x0002 | 11347 | False | 1 |
| hol-overdue-down-burst-after-blocked-up | 7 | 137167 | 147604 | 147614 | 147714 | 100 | 6/0x0004 | 10447 | False | 1 |
| hol-same-key-repeated-note-serialization | 0 | 100000 | 100000 | 100000 | 110000 | 10000 | none | 0 | False | 1 |
| hol-same-key-repeated-note-serialization | 1 | 117167 | 127167 | 127167 | 127217 | 50 | 0/0x0001 | 10000 | False | 1 |
| hol-same-key-repeated-note-serialization | 2 | 135000 | 143884 | 143884 | 143934 | 50 | 1/0x0001 | 8884 | False | 1 |
| hol-same-key-repeated-note-serialization | 3 | 152167 | 161101 | 161101 | 161151 | 50 | 2/0x0001 | 8934 | False | 1 |
| hol-chord15-fps30-margin0-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin0-hold1 | 1 | 133334 | 133484 | 133484 | 133634 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin0-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin0-hold1.25 | 1 | 141668 | 141818 | 141818 | 141968 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin0-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin0-hold1.5 | 1 | 150001 | 150151 | 150151 | 150301 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin500-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin500-hold1 | 1 | 133834 | 133984 | 133984 | 134134 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin500-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin500-hold1.25 | 1 | 142168 | 142318 | 142318 | 142468 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin500-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin500-hold1.5 | 1 | 150501 | 150651 | 150651 | 150801 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin3000-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin3000-hold1 | 1 | 136334 | 136484 | 136484 | 136634 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin3000-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin3000-hold1.25 | 1 | 144668 | 144818 | 144818 | 144968 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps30-margin3000-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps30-margin3000-hold1.5 | 1 | 153001 | 153151 | 153151 | 153301 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin0-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin0-hold1 | 1 | 116667 | 116817 | 116817 | 116967 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin0-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin0-hold1.25 | 1 | 120834 | 120984 | 120984 | 121134 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin0-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin0-hold1.5 | 1 | 125001 | 125151 | 125151 | 125301 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin500-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin500-hold1 | 1 | 117167 | 117317 | 117317 | 117467 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin500-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin500-hold1.25 | 1 | 121334 | 121484 | 121484 | 121634 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin500-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin500-hold1.5 | 1 | 125501 | 125651 | 125651 | 125801 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin3000-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin3000-hold1 | 1 | 119667 | 119817 | 119817 | 119967 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin3000-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin3000-hold1.25 | 1 | 123834 | 123984 | 123984 | 124134 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps60-margin3000-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps60-margin3000-hold1.5 | 1 | 128001 | 128151 | 128151 | 128301 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin0-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin0-hold1 | 1 | 108334 | 108484 | 108484 | 108634 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin0-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin0-hold1.25 | 1 | 110418 | 110568 | 110568 | 110718 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin0-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin0-hold1.5 | 1 | 112501 | 112651 | 112651 | 112801 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin500-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin500-hold1 | 1 | 108834 | 108984 | 108984 | 109134 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin500-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin500-hold1.25 | 1 | 110918 | 111068 | 111068 | 111218 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin500-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin500-hold1.5 | 1 | 113001 | 113151 | 113151 | 113301 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin3000-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin3000-hold1 | 1 | 111334 | 111484 | 111484 | 111634 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin3000-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin3000-hold1.25 | 1 | 113418 | 113568 | 113568 | 113718 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps120-margin3000-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps120-margin3000-hold1.5 | 1 | 115501 | 115651 | 115651 | 115801 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin0-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin0-hold1 | 1 | 104167 | 104317 | 104317 | 104467 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin0-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin0-hold1.25 | 1 | 105209 | 105359 | 105359 | 105509 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin0-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin0-hold1.5 | 1 | 106251 | 106401 | 106401 | 106551 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin500-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin500-hold1 | 1 | 104667 | 104817 | 104817 | 104967 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin500-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin500-hold1.25 | 1 | 105709 | 105859 | 105859 | 106009 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin500-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin500-hold1.5 | 1 | 106751 | 106901 | 106901 | 107051 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin3000-hold1 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin3000-hold1 | 1 | 107167 | 107317 | 107317 | 107467 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin3000-hold1.25 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin3000-hold1.25 | 1 | 108209 | 108359 | 108359 | 108509 | 150 | 0/0x7fff | 150 | False | 1 |
| hol-chord15-fps240-margin3000-hold1.5 | 0 | 100000 | 100000 | 100000 | 100150 | 150 | none | 0 | False | 1 |
| hol-chord15-fps240-margin3000-hold1.5 | 1 | 109251 | 109401 | 109401 | 109551 | 150 | 0/0x7fff | 150 | False | 1 |

## Startup and memory

| Generations | Actions | Compile/materialize (us) | Schedule clone (us) | Coordinator init (us) | Coordinator clone (us; test-support only) | Prepared build/reset (us) | Prepared entries | Build allocations (count / requested bytes) | Peak process working set (bytes) | Available budget (us) | Prepared-path budget outcome |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | --- |
| 100 | 200 | 59 | 8 | 17 | 13 | 226 | 200 | 219 / 276292 | 7204864 | 48000 | WOULD_ADMIT_WITHIN_SCOPED_MIN_PREROLL_BUDGET |
| 1000 | 2000 | 339 | 52 | 50 | 83 | 1610 | 2000 | 2025 / 2739208 | 7208960 | 48000 | WOULD_ADMIT_WITHIN_SCOPED_MIN_PREROLL_BUDGET |
| 10000 | 20000 | 2639 | 270 | 274 | 372 | 14900 | 20000 | 20033 / 27982768 | 10063872 | 48000 | WOULD_ADMIT_WITHIN_SCOPED_MIN_PREROLL_BUDGET |
| 100000 | 200000 | 28490 | 1786 | 2298 | 2569 | 162697 | 200000 | 200039 / 276682816 | 307691520 | 48000 | WOULD_REJECT_SCOPED_MIN_PREROLL_BUDGET |

Allocation counts/bytes are successful allocation and realloc requests in the probe process during each named operation; they exclude deallocation and allocator metadata. Process working set is sampled separately by PowerShell every 5 ms and includes shared resident pages. Neither metric is inferred from the other. Schedule compile/materialize is separate from coordinator initialization and prepared-stream build. The scoped budget comparison includes coordinator initialization plus prepared build/reset, and excludes other worker startup work.

The RuntimeSchedule clone that supplies the coordinator its owned schedule is measured separately. RuntimeDispatchCoordinator cloning exists only in test-support for characterization; the deep clone column is not part of production startup. Actual coordinator initialization and post-preparation reconstruction are measured in their own columns.
The prepared-path budget outcome is a scoped characterization result: an out-of-budget measurement is labeled WOULD_REJECT. No production boot was attempted, so this does not claim an observed product rejection or model excluded startup work.

## Offline receiver frame-polling model

| FPS | Margin (us) | Cases | Missed Down states | Missed separating Up states |
| ---: | ---: | ---: | ---: | ---: |
| 30 | 0 | 135 | 83 | 0 |
| 30 | 500 | 135 | 72 | 0 |
| 30 | 3000 | 135 | 72 | 0 |
| 60 | 0 | 135 | 83 | 0 |
| 60 | 500 | 135 | 72 | 0 |
| 60 | 3000 | 135 | 69 | 0 |
| 120 | 0 | 135 | 83 | 0 |
| 120 | 500 | 135 | 69 | 0 |
| 120 | 3000 | 135 | 60 | 0 |
| 240 | 0 | 135 | 82 | 0 |
| 240 | 500 | 135 | 68 | 0 |
| 240 | 3000 | 135 | 42 | 0 |

### 17,167 us short-hold reference cases

| Poll phase | Receiver stall (frames) | Down observed | Separating Up observed |
| --- | ---: | --- | --- |
| 0 | 0 | True | True |
| 0 | 1 | False | True |
| 3T/4 | 0 | False | True |
| 3T/4 | 1 | False | True |
| T_exact_boundary | 0 | False | True |
| T_exact_boundary | 1 | False | True |

The polling model is offline. It reports state samples for all fixed phases, stalls, and independent Down/Up delivery skews. Actual ReceiveOnly sink observations are a separate evidence layer; Sky consumption remains unknown. DWM or monitor refresh rate is not treated as game polling.

## Fixed disposition

Head-of-line blocking, overdue bursts, startup cost, and long-hold receiver limitations remain documented characterization findings. No scheduler rewrite, storage optimization, timing/policy change, or new receiver guarantee is proposed.
